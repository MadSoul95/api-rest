const express = require('express');
const app = express();
const cors = require('cors');
const createLog = require("./bech/logs/createLog").fn_createLog;

//MODULOS
const morgan = require('morgan');
const bodyParser = require('body-parser');

//Settings
app.set('port', process.env.PORT || 3402);

//CREAR UNA API
//MIDDLEWARES
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

try {
    //rutas del servidor, requerir modulo
    //BECH =>
    require('./bech/routes/modulesRoutes')(app); 
} catch (err){
    console.error(err);
    createLog.error('Error Interno => ' + err);
}

//static files
app.listen(app.get('port'), () => {
    console.log('Server Iniciado en Puerto => '+app.get('port')+'');
    createLog.info('Server Iniciado en Puerto => '+app.get('port')+'');
});

//Manejo de Errores
process
  .on('unhandledRejection', (reason, p) => {
    // Use your own logger here
    console.error(reason, 'Unhandled Rejection at Promise', p);
    createLog.error('Error Interno => ' + err);
  })
  .on('uncaughtException', err => {
    // Use your own logger here
    console.error(err, 'Uncaught Exception thrown');
    createLog.fatal('Error Interno => ' + err);
    // Optional: Ensure process will stop after this
    process.exit(1);
  });